import { frameworks, content } from '$lib/docs/config.ts';
import { error } from '@sveltejs/kit';

export function load({ params }) {
	const { version, framework, instruction } = params;
    
	if (!frameworks.includes(framework)) {
		throw error(404, 'Framework not supported');
	}

	return {
		version,
		framework,
		instruction
		// code: content[framework]?.[instruction] ?? '// Not implemented yet'
	};
}
